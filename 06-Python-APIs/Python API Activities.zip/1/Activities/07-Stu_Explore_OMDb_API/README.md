# OMDb API

* **Instructions:**

  * Read the OMDb documentation, and make a few API calls to
    get some information about your favorite movie: <http://www.omdbapi.com/>

- - -

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
