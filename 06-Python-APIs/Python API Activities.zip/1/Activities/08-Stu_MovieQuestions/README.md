# Instructions

Use the OMDb API to retrieve and print the following information.

* Who was the director of the movie *Aliens*?

* What was the movie *Gladiator* rated?

* What year was *50 First Dates* released?

* Who wrote *Moana*?

* What was the plot of the movie *Sing*?

- - -

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
