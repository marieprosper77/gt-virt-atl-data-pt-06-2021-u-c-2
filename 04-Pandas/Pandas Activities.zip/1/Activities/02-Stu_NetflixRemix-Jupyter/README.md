# Netflix Remix

## Instructions

* Using `Netflix.py` as a jumping off point, convert the application so that it runs properly within a Jupyter Notebook.

* Make sure to have the application print out the user's input, the path to `Netflix_Ratings.csv`, and the final rating/review for the film in different cells.

## Bonus

* Go through any of the activities from last week and attempt to convert them to run within a Jupyter Notebook. While doing this, try to split up the code into cells and print out the outputs.
