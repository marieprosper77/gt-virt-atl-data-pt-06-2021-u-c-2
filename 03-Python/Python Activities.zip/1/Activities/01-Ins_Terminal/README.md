Instructor demo
