## Basic Variables

## Instructions

* Create two different variables that will take the input of your first name and your neighbor's first name.

* Create two more inputs that will ask how many months each of you has been coding.

* Finally, display a result with both your names and the total amount of months coding.
