# Module Playground

## Instructions

* There are tons of built-in modules for Python: 

  * Look through some of Python's modules and play around with them.

  * [List of Built-In Python Modules](https://docs.python.org/3/py-modindex.html)

